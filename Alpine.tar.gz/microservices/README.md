# To Do List
- Add more routes for each graph
- Setup CI/CD
- Add unit test


# Building
You can try it out using the following command:

Build and run:
```
docker-compose -f docker-compose.yml up
```
Open `http://localhost:8080` in your browser to manage the DB.
