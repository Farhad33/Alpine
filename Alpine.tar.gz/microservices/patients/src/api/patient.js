const patientService = require('../services/patient-service');


module.exports = (app) => {
    
    app.get('/patients', async (req,res,next) => {
        console.log("app.get('/patients' XXXXXX");
        const  patientInserted = await patientService.getAllPatients()
        res.send(patientInserted)
    });
    app.get('/', async (req,res,next) => {
        console.log("app.get('/' XXXXXX");
        res.send('OK')
    });

}
