// database related modules
module.exports = {
    db: require('./connection'),
    patientRepository: require('./repository/patient-repository'),
}