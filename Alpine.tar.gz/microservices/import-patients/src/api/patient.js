const patientService = require('../services/patient-service');


module.exports = (app) => {

    app.post('/import-patients', async (req,res,next) => {
        let patients = await patientService.importPatients()
        // res.json(patients)
        res.send('OK')
    });

    app.post('/signup', async (req,res,next) => {
        const { email, password, phone } = req.body;
        const { data } = await service.SignUp({ email, password, phone}); 
        res.json(data);
    });
}
