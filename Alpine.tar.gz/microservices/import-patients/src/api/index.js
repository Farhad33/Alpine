
module.exports = {
    patient: require('./patient'),
}
